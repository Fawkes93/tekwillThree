/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package soccer;

public class Goal {   
    public Team theTeam;
    public Player thePlayer;
    public double theTime;
}
