/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package soccer;

public class Goal extends GameEvent {   

    public String toString(){
        return "Goal scored";
    }
}
