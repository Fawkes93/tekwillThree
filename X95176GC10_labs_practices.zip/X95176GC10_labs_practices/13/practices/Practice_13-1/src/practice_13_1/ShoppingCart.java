/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package practice_13_1;

public class ShoppingCart {
    public static void main(String args[]){ 
	// Instantiate a Shirt object and call display() on the object reference
        
       
    }
}    
