/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package practice_13_2;

public class ShoppingCart {
    public static void main(String args[]){ 
        Shirt shirt = new Shirt(25.99, 'M', 'P');
        shirt.display();       
    }
}    
