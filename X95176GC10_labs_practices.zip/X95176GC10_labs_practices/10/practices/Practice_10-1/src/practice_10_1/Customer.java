/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package practice_10_1;

public class Customer {
    public String name;
    public String ssn;
   
    // Encapsulate this class.  Make ssn read only.

}
