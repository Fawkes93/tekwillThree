/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package practice_07_3;

public class ShoppingCart {
    public static void main(String[] args) {
        int int1;
        
	// Declare and initialize variables of type long, float, and char.
        
	// Print the long variable.

        // Assign the long to the int and print the int variable.

    }
}